
-- FILES/FOLDERS---

readme.txt				this file
binaries\				executables of the source code provided
hwinterface_
activex_control_source\			Source code and project files of hwinterface activex control
Inpout32_dll_source\			Source code and project files of Inpout32.dll for WIN 9x/NT/2000/XP
kernel_mode_driver_source\		source code of kernel mode driver used in this project
test applications\			test applications 		



copy inpout32.dll to system directory before running test program

send queries and doubts to  logix4u mail ID found at homepage
visit 		http://www.logix4u.net

no explicit licence is neede to use this dll for non - commercial applications. for commercial applications , contact the webmaster

	